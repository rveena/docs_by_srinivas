ECHO is on.
ECHO is on.
