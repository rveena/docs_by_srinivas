#! /bin/sh

rm -rf work/plugins
mvn -Dmaven.test.skip=true -DskipTests=true clean hpi:run
