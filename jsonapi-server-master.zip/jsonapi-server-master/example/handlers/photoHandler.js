const jsonApi = require('../..')

module.exports = new jsonApi.MemoryHandler()
module.exports.delete = null
