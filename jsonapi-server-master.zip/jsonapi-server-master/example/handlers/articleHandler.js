const jsonApi = require('../..')

module.exports = new jsonApi.MemoryHandler()
