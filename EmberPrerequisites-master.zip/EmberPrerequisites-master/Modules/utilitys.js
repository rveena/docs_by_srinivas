/**
 * Created by skolapar on 4/7/2017.
 */
function generateRandom() {
    return Math.random();
}

function sum(a, b) {
    return a + b;
}

export { generateRandom, sum }