/**
 * Created by skolapar on 4/7/2017.
 */
/**
 * Created by skolapar on 4/7/2017.
 */

import{ generateRandom, sum } from 'Modules/utilitys.js';
console.log(generateRandom()); //logs a random number
