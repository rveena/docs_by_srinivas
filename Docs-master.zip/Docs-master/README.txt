Kafka
----------
https://www.codenotfound.com/2016/09/spring-kafka-consumer-
producer-example.html
https://mapr.com/blog/getting-started-sample-programs-
apache-kafka-09/
https://www.confluent.io/product/confluent-platform/
