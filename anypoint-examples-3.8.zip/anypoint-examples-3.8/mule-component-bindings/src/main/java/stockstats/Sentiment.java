/**
 * MuleSoft Examples
 * Copyright 2014 MuleSoft, Inc.
 *
 * This product includes software developed at
 * MuleSoft, Inc. (http://www.mulesoft.com/).
 */

package stockstats;

public enum Sentiment {
	POSITIVE, NEGATIVE, NEUTRAL;
}
