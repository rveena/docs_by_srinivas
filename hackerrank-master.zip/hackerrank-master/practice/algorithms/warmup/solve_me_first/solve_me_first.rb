def solveMeFirst (a, b)
    return a+b
end

val1 = gets.to_i
val2 = gets.to_i
sum = solveMeFirst(val1,val2)
print (sum)
