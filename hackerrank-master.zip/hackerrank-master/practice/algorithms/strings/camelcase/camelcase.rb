text = gets.strip
words = text.split(/[A-Z]/)
puts words.size