#!/bin/bash

for i in {1..99..2}
do
  echo $i
done
