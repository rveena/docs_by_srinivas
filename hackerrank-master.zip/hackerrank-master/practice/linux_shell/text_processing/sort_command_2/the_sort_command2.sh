#!/bin/bash

sort -r
