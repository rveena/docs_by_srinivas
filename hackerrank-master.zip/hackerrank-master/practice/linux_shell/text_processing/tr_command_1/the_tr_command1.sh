#!/bin/bash

tr "(" "\[" | tr ")" "]"
