#!/bin/bash

tr -d [a-z]
