#!/bin/bash

head -c 20
