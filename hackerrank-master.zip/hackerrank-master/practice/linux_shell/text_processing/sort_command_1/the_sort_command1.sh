#!/bin/bash

sort -n
