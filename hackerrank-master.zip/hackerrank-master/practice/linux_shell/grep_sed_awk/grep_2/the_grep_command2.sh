#!/bin/bash

grep -i "\bthe\b"
