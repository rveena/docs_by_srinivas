#!/bin/bash

grep "\bthe\b"
