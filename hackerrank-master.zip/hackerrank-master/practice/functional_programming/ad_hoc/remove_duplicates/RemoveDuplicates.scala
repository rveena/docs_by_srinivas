object RemoveDuplicates extends App {
  println(Console.readLine.distinct)
}
