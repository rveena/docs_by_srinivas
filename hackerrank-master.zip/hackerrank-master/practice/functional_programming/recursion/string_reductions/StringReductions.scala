object StringReductions extends App {
  println(io.Source.stdin.getLines().toList.head.distinct)
}
