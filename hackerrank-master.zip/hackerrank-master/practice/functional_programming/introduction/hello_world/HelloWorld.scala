object HelloWorld extends App {
  def f() = println("Hello World")

  f()
}