tests = gets.chomp.to_i
tests.times do
    pairs = gets.chomp.to_i
    result = pairs + 1
    puts result
end