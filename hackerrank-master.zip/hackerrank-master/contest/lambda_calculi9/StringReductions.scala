object StringReductions extends App {
  println(Console.readLine.distinct)
}