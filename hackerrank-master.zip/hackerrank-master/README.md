# hackerrank
Solutions of [Hackerrank](https://www.hackerrank.com) challenges in various languages.

For explanations see my [personal page](http://pidanic.com/hackerrank/).
