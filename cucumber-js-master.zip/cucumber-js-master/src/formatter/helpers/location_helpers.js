export function formatLocation(obj) {
  return `${obj.uri}:${obj.line}`
}
