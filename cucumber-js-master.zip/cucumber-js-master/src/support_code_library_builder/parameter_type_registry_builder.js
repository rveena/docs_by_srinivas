import { ParameterTypeRegistry } from 'cucumber-expressions'

function build() {
  return new ParameterTypeRegistry()
}

export default { build }
