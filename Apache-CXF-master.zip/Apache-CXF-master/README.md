# Apache-CXF
---------------------

CXF jars link:http://www.apache.org/dyn/closer.cgi?path=/cxf/2.6.13/apache-cxf-2.6.13.zip
