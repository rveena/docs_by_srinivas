## Utility classes for creating Cucumber StepDefs for Ready! API TestServer

Have a look at the declarative Cucumber sample in the TestServer samples project how these classes
can be used to create your own Gherkin vocabulary running against the TestServer